﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace MinefieldGame.Common.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
